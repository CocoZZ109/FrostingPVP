# FrostingPVP

A Paper server plugin starter for a Christmas-themed PvP network.

## Target
- Paper 26.2 API
- Java 25
- Gradle
- Output: `FrostingPVP-1.0.0.jar`

## Build
1. Install JDK 25 and Gradle.
2. Open this folder in IntelliJ IDEA (or another Gradle IDE), or run `gradle build`.
3. Find the plugin at `build/libs/FrostingPVP-1.0.0.jar`.
4. Put the JAR in your Paper server's `plugins` folder and restart.

The uploaded Paper server JAR is not a Java compiler; build this project with Gradle.

## First-time setup
1. Join the server as an operator.
2. Stand at the desired lobby spawn and run `/admin setlobby`.
3. Go to each arena spawn and run `/admin arena create <name> <mode>`.
   - Modes: `FFA`, `BEDWARS`, `PRACTICE`, `CRYSTAL`, `CLASSIC`
4. Players use `/pvp` or `/games` to open the chest selector.
5. Players can challenge each other with `/duel <player>`; the target accepts with `/accept <player>`.
6. Operators use `/admin` for the admin command list.

## Included in this starter build
- Chest-based game selector, arena picker, and ranks display.
- Random arena selection from configured arenas.
- Arena spawn teleporting and starter kits for each mode.
- Admin maintenance toggle, clean shutdown, lobby setup, arena setup, kit saving, and config reload.
- Basic duel request / accept flow.
- Practice target dummy.

## Important scope notes
This is a working foundation, not a finished production network:
- BedWars currently has a mode entry and starter kit, but not yet the full bed-protection, team, shop, respawn, or win-condition systems.
- Practice currently spawns a stationary target dummy, not a combat AI bot.
- Duel requests are implemented, but duel matchmaking, dedicated duel arenas, countdowns, and round results still need to be added.
- Ranks are currently a display menu; actual rank permissions/perks and a purchase system are not included.
- The arena builder commands save spawn points; they do not automatically construct the Christmas maps. Build the lobby and arenas in-game, then save their spawn locations.

Use a test server first. Back up your world before installing new plugins.
